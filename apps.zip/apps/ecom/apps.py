from django.apps import AppConfig


class EcomConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.ecom'
    verbose_name = 'E-Commerce'
